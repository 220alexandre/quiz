
    <?php 
    include("./public/header.html");
    ?>
    
<?php 
include('./public/footer.html');
?>
